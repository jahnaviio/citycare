# CityCare – Frontend + Backend

## Run (needs only Node.js 18+, no `npm install`)
```
cp .env.example .env      # edit passwords
node server.js
```
Open http://localhost:3000

Self-test: `node test.js`

## How a report travels
1. Citizen fills the form (category, GPS/location, photo, name, mobile) → `POST /api/reports`
2. Backend saves it, assigns the department, and **forwards it to the government platform** (`govt.js`)
3. Government platform replies later by calling `POST /api/govt/webhook` (header `X-Webhook-Secret`)
4. Citizen sees the reply under **Track** (report ID + mobile); the public dashboard shows status only
5. Department staff log in on the Dashboard → see contact details, change status, reply, retry forwarding

## Connecting the REAL government platform
Demo mode uses a built-in mock department. For the real one you need API access (URL + key) from
the department (e.g. GVMC) – ask them for their grievance/complaint API document, then:
1. Put `GOVT_API_URL` and `GOVT_API_KEY` in `.env`
2. Edit `buildPayload()` and `extractTicket()` in `govt.js` to match their field names
3. Give them your webhook URL (`PUBLIC_BASE_URL/api/govt/webhook`) and `GOVT_WEBHOOK_SECRET`
Failed forwards are retried automatically (every minute, up to 8 times).

## Deploy
Any Node host works (Render, Railway, VPS). Set the `.env` values as environment variables,
`TRUST_PROXY=1`, and `PUBLIC_BASE_URL` to your https address. Keep the `data/` folder on a persistent disk.

## Files
- `server.js` API, login, storage, webhook, mock government platform
- `govt.js` department mapping + government integration (edit this one)
- `public/index.html` your frontend, now connected to the API
- `data/` reports (db.json) and photos – created automatically
