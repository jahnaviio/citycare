'use strict';
/**
 * CityCare backend – zero dependencies (Node 18+).  Run:  node server.js
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

// ---------- tiny .env loader ----------
try {
  for (const line of fs.readFileSync(path.join(__dirname, '.env'), 'utf8').split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/);
    if (m && !(m[1] in process.env)) process.env[m[1]] = m[2].replace(/^["']|["']$/g, '');
  }
} catch (e) { /* no .env file – fine */ }

const PORT = +process.env.PORT || 3000;
const govt = require('./govt');

const DATA_DIR = path.join(__dirname, 'data');
const PHOTO_DIR = path.join(DATA_DIR, 'photos');
const DB_FILE = path.join(DATA_DIR, 'db.json');
const PUBLIC_DIR = path.join(__dirname, 'public');
fs.mkdirSync(PHOTO_DIR, { recursive: true });

const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || crypto.randomBytes(6).toString('hex');
const WEBHOOK_SECRET = process.env.GOVT_WEBHOOK_SECRET || crypto.randomBytes(16).toString('hex');
process.env.GOVT_WEBHOOK_SECRET = WEBHOOK_SECRET;
const TOKEN_KEY = crypto.randomBytes(32); // admin sessions end when the server restarts
const TRUST_PROXY = process.env.TRUST_PROXY === '1';

// ---------- storage (JSON file, written atomically) ----------
let db = { reports: [] };
try { db = JSON.parse(fs.readFileSync(DB_FILE, 'utf8')); } catch (e) { /* first run */ }
function save() {
  const tmp = DB_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(db));
  fs.renameSync(tmp, DB_FILE);
}
const find = id => db.reports.find(r => r.id === id);

// ---------- helpers ----------
const sha = s => crypto.createHash('sha256').update(String(s)).digest();
const safeEq = (a, b) => crypto.timingSafeEqual(sha(a), sha(b));
const ip = req => (TRUST_PROXY && String(req.headers['x-forwarded-for'] || '').split(',')[0].trim()) || req.socket.remoteAddress || '?';

const hits = new Map();
function limited(key, max, windowMs) {
  const now = Date.now();
  const arr = (hits.get(key) || []).filter(t => now - t < windowMs);
  if (arr.length >= max) { hits.set(key, arr); return true; }
  arr.push(now); hits.set(key, arr); return false;
}
setInterval(() => { const now = Date.now(); for (const [k, v] of hits) if (!v.some(t => now - t < 3600e3)) hits.delete(k); }, 600e3).unref();

function makeToken() {
  const exp = Date.now() + 8 * 3600e3;
  const sig = crypto.createHmac('sha256', TOKEN_KEY).update(String(exp)).digest('base64url');
  return exp + '.' + sig;
}
function validToken(t) {
  const [exp, sig] = String(t || '').split('.');
  if (!exp || !sig || +exp < Date.now()) return false;
  const good = crypto.createHmac('sha256', TOKEN_KEY).update(exp).digest('base64url');
  return safeEq(sig, good);
}
const isAdmin = req => validToken((req.headers.authorization || '').replace(/^Bearer\s+/i, ''));

function send(res, code, obj, extra) {
  const body = JSON.stringify(obj);
  res.writeHead(code, Object.assign({ 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }, extra));
  res.end(body);
}
function readBody(req, limit = 700 * 1024) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on('data', c => { size += c.length; if (size > limit) { reject(Object.assign(new Error('Request too large'), { status: 413 })); req.destroy(); } else chunks.push(c); });
    req.on('end', () => { try { resolve(chunks.length ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {}); } catch (e) { reject(Object.assign(new Error('Invalid JSON'), { status: 400 })); } });
    req.on('error', reject);
  });
}
const clean = (s, n) => String(s == null ? '' : s).replace(/[\u0000-\u001f\u007f]/g, ' ').trim().slice(0, n);
const normPhone = p => String(p || '').replace(/\D/g, '').slice(-10);

// What the whole world may see (NO name / phone).
const publicView = r => ({ id: r.id, cat: r.cat, loc: r.loc, created: r.created, photo: r.photo, status: r.status, dept: r.dept });
// What the citizen who filed it may see.
const citizenView = r => Object.assign(publicView(r), { ticket: r.ticket || null, desc: r.desc, replies: r.replies, updated: r.updated });
// Full record for department staff.
const adminView = r => Object.assign(citizenView(r), { name: r.name, phone: r.phone, lat: r.lat, lng: r.lng, govt: r.govt });

function newId() {
  for (;;) {
    const id = 'CC-' + crypto.randomBytes(4).toString('hex').slice(0, 5).toUpperCase();
    if (!find(id)) return id;
  }
}

// ---------- forwarding to the government platform ----------
async function forwardReport(r) {
  r.govt.attempts++;
  r.govt.lastTry = Date.now();
  try {
    const out = await govt.forward(r);
    r.ticket = out.ticket;
    r.govt.state = 'sent';
    r.govt.error = '';
    r.replies.push({ at: Date.now(), from: 'system', text: `Your report was forwarded to ${r.dept}. Ticket number: ${r.ticket}.` });
    r.updated = Date.now();
  } catch (e) {
    r.govt.state = 'failed';
    r.govt.error = String(e.message || e).slice(0, 200);
    console.error(`[govt] ${r.id} forward failed (attempt ${r.govt.attempts}): ${r.govt.error}`);
  }
  save();
}
// Retry failed / pending forwards every minute (max 8 attempts each).
setInterval(() => {
  for (const r of db.reports) {
    if (r.govt.state !== 'sent' && r.govt.attempts < 8 && Date.now() - (r.govt.lastTry || 0) > 60e3) forwardReport(r);
  }
}, 60e3).unref();

// ---------- API ----------
async function api(req, res, url) {
  const p = url.pathname, m = req.method;

  // Citizen: file a report
  if (p === '/api/reports' && m === 'POST') {
    if (limited('rep:' + ip(req), 10, 3600e3)) return send(res, 429, { error: 'Too many reports from this device. Please try again later.' });
    const b = await readBody(req);
    const k = Number.isInteger(b.catIndex) ? b.catIndex : -1;
    if (k < 0 || k > 5) return send(res, 400, { error: 'Invalid category' });
    const phone = normPhone(b.phone);
    if (!/^[6-9]\d{9}$/.test(phone)) return send(res, 400, { error: 'Enter a valid 10-digit mobile number.' });
    const loc = clean(b.loc, 200);
    if (!loc) return send(res, 400, { error: 'Location is required.' });
    const lat = Number(b.lat), lng = Number(b.lng);
    const hasGps = Number.isFinite(lat) && Number.isFinite(lng) && Math.abs(lat) <= 90 && Math.abs(lng) <= 180 && (b.lat !== null && b.lat !== '');

    const id = newId();
    let photo = '';
    if (typeof b.photo === 'string' && b.photo) {
      const mm = b.photo.match(/^data:image\/jpeg;base64,([A-Za-z0-9+/=]+)$/);
      const buf = mm && Buffer.from(mm[1], 'base64');
      if (!buf || buf.length > 450 * 1024 || buf[0] !== 0xff || buf[1] !== 0xd8) return send(res, 400, { error: 'Photo must be a JPEG under 450 KB.' });
      fs.writeFileSync(path.join(PHOTO_DIR, id + '.jpg'), buf);
      photo = `/photos/${id}.jpg`;
    }
    const r = {
      id, catIndex: k, cat: govt.CATEGORIES[k], dept: govt.DEPARTMENTS[k],
      loc, lat: hasGps ? lat : null, lng: hasGps ? lng : null,
      desc: clean(b.desc, 500), photo, name: clean(b.name, 80), phone,
      created: Date.now(), updated: Date.now(), status: 'R', ticket: null,
      replies: [], govt: { state: 'pending', attempts: 0, lastTry: 0, error: '' }
    };
    db.reports.unshift(r);
    save();
    await forwardReport(r); // quick (10s max); the citizen sees the result immediately
    return send(res, 201, { id: r.id, dept: r.dept, ticket: r.ticket, forwarded: r.govt.state === 'sent' });
  }

  // Public dashboard (no personal data)
  if (p === '/api/reports' && m === 'GET') {
    return send(res, 200, { reports: db.reports.slice(0, 300).map(publicView) });
  }

  // Citizen: track my report (id + phone)
  if (p === '/api/track' && m === 'POST') {
    if (limited('trk:' + ip(req), 30, 600e3)) return send(res, 429, { error: 'Too many attempts. Please wait a few minutes.' });
    const b = await readBody(req);
    const r = find(clean(b.id, 20).toUpperCase());
    if (!r || !safeEq(r.phone, normPhone(b.phone))) return send(res, 404, { error: 'No report found with that ID and mobile number.' });
    return send(res, 200, { report: citizenView(r) });
  }

  // Government platform → us (status updates and replies)
  if (p === '/api/govt/webhook' && m === 'POST') {
    const given = req.headers['x-webhook-secret'] || (req.headers.authorization || '').replace(/^Bearer\s+/i, '') || req.headers['x-api-key'] || '';
    if (!safeEq(given, WEBHOOK_SECRET)) return send(res, 401, { error: 'Unauthorized' });
    const b = await readBody(req);
    const ticket = clean(b.ticketId || b.ticket_id || b.ticket, 60);
    const r = db.reports.find(x => (ticket && x.ticket === ticket) || (b.reference && x.id === clean(b.reference, 20)));
    if (!r) return send(res, 404, { error: 'Unknown ticket' });
    const s = govt.normalizeStatus(b.status);
    if (s) r.status = s;
    const msg = clean(b.message || b.remarks || b.reply, 600);
    if (msg) r.replies.push({ at: Date.now(), from: 'department', officer: clean(b.officer, 80), text: msg });
    r.updated = Date.now();
    save();
    return send(res, 200, { ok: true });
  }

  // ---- Department (admin) ----
  if (p === '/api/admin/login' && m === 'POST') {
    if (limited('login:' + ip(req), 8, 900e3)) return send(res, 429, { error: 'Too many attempts. Try again in 15 minutes.' });
    const b = await readBody(req, 4096);
    if (!safeEq(b.password || '', ADMIN_PASSWORD)) return send(res, 401, { error: 'Wrong password' });
    return send(res, 200, { token: makeToken() });
  }
  if (p.startsWith('/api/admin/')) {
    if (!isAdmin(req)) return send(res, 401, { error: 'Please log in as department.' });
    const mm = p.match(/^\/api\/admin\/reports\/(CC-[A-Z0-9]{5})(\/resend)?$/);
    if (mm) {
      const r = find(mm[1]);
      if (!r) return send(res, 404, { error: 'Report not found' });
      if (!mm[2] && m === 'GET') return send(res, 200, { report: adminView(r) });
      if (!mm[2] && m === 'PATCH') {
        const b = await readBody(req, 8192);
        if (['R', 'P', 'S'].includes(b.status)) r.status = b.status;
        const msg = clean(b.message, 600);
        if (msg) r.replies.push({ at: Date.now(), from: 'department', officer: 'CityCare department', text: msg });
        r.updated = Date.now(); save();
        return send(res, 200, { report: adminView(r) });
      }
      if (mm[2] && m === 'POST') {
        if (r.govt.state === 'sent') return send(res, 400, { error: 'Already forwarded.' });
        await forwardReport(r);
        return send(res, 200, { report: adminView(r) });
      }
    }
  }
  return send(res, 404, { error: 'Not found' });
}

// ---------- Built-in MOCK government platform (demo only) ----------
// Pretends to be the department: gives a ticket, then replies via the real webhook.
async function mockGovt(req, res, url) {
  if (url.pathname !== '/mock-govt/tickets' || req.method !== 'POST') return send(res, 404, { error: 'Not found' });
  if (govt.cfg().live) return send(res, 404, { error: 'Mock disabled' });
  const given = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  if (!safeEq(given, WEBHOOK_SECRET)) return send(res, 401, { error: 'Unauthorized' });
  const b = await readBody(req);
  const ticketId = 'GVMC-' + new Date().getFullYear() + '-' + crypto.randomInt(10000, 99999);
  const d = (+process.env.MOCK_DELAY_SECONDS || 20) * 1000;
  const call = (status, message, officer) => setTimeout(() => {
    fetch(`http://127.0.0.1:${PORT}/api/govt/webhook`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Webhook-Secret': WEBHOOK_SECRET },
      body: JSON.stringify({ ticketId, reference: b.reference, status, message, officer })
    }).catch(() => {});
  }, status === 'In Progress' ? d : d * 2);
  call('In Progress', `Complaint accepted and assigned to the ${b.department} section. A team will visit the location.`, 'Ward Officer (demo)');
  call('Resolved', 'Work completed at the location. Thank you for reporting.', 'Ward Officer (demo)');
  return send(res, 201, { ticketId });
}

// ---------- static files ----------
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.jpg': 'image/jpeg', '.png': 'image/png', '.ico': 'image/x-icon', '.svg': 'image/svg+xml', '.json': 'application/json' };
function serveFile(res, file) {
  fs.readFile(file, (err, buf) => {
    if (err) { res.writeHead(404, { 'Content-Type': 'text/plain' }); return res.end('Not found'); }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream', 'Cache-Control': file.endsWith('.jpg') ? 'public, max-age=86400' : 'no-cache' });
    res.end(buf);
  });
}

const server = http.createServer(async (req, res) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'same-origin');
  try {
    const url = new URL(req.url, 'http://x');
    if (url.pathname.startsWith('/api/')) return await api(req, res, url);
    if (url.pathname.startsWith('/mock-govt/')) return await mockGovt(req, res, url);
    if (req.method !== 'GET' && req.method !== 'HEAD') return send(res, 405, { error: 'Method not allowed' });
    const ph = url.pathname.match(/^\/photos\/(CC-[A-Z0-9]{5})\.jpg$/);
    if (ph) return serveFile(res, path.join(PHOTO_DIR, ph[1] + '.jpg'));
    if (url.pathname === '/' || url.pathname === '/index.html') return serveFile(res, path.join(PUBLIC_DIR, 'index.html'));
    const f = path.normalize(path.join(PUBLIC_DIR, decodeURIComponent(url.pathname)));
    if (!f.startsWith(PUBLIC_DIR + path.sep)) return send(res, 403, { error: 'Forbidden' });
    return serveFile(res, f);
  } catch (e) {
    if (!res.headersSent) send(res, e.status || 500, { error: e.status ? e.message : 'Server error' });
    if (!e.status) console.error(e);
  }
});

if (require.main === module) {
  server.listen(PORT, () => {
    const c = govt.cfg();
    console.log(`\nCityCare running at http://localhost:${PORT}`);
    console.log(`Government platform: ${c.live ? 'LIVE → ' + c.url : 'MOCK (demo). Set GOVT_API_URL in .env for the real one'}`);
    if (!process.env.ADMIN_PASSWORD) console.log(`Department password (random this run): ${ADMIN_PASSWORD}`);
    console.log('');
  });
}
module.exports = { server, db };
