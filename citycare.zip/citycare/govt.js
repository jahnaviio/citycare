'use strict';
/**
 * Government platform integration.
 *
 * LIVE mode  (GOVT_API_URL set):  POSTs each report to the department's API.
 * MOCK mode  (GOVT_API_URL empty): talks to the built-in demo platform in server.js,
 *                                  which "replies" later through the normal webhook.
 *
 * >>> When you receive the real API specification, ONLY edit buildPayload() and
 * >>> extractTicket() below. Nothing else in the project needs to change.
 */

// Which department receives which category (edit names to match your city).
const DEPARTMENTS = [
  'GVMC Engineering (Roads)',          // 0 Road damage
  'GVMC Engineering (Roads)',          // 1 Roadblock
  'GVMC Sanitation / Public Health',   // 2 Dead animal
  'Traffic Police / Roadside Help',    // 3 Out of fuel
  'Traffic Police / Roadside Help',    // 4 Lost route
  'Visakhapatnam City Police'          // 5 Unsafe area
];
const CATEGORIES = ['Road damage', 'Roadblock', 'Dead animal', 'Out of fuel', 'Lost route', 'Unsafe area'];

function cfg() {
  const base = (process.env.PUBLIC_BASE_URL || `http://localhost:${process.env.PORT || 3000}`).replace(/\/$/, '');
  const live = !!process.env.GOVT_API_URL;
  return {
    base,
    live,
    url: live ? process.env.GOVT_API_URL : `http://127.0.0.1:${process.env.PORT || 3000}/mock-govt/tickets`,
    key: process.env.GOVT_API_KEY || process.env.GOVT_WEBHOOK_SECRET || ''
  };
}

// What we send to the government platform. Adjust field names to their spec.
function buildPayload(r, base) {
  return {
    reference: r.id,
    category: r.cat,
    department: r.dept,
    description: r.desc,
    location: { text: r.loc, latitude: r.lat, longitude: r.lng },
    photoUrl: r.photo ? base + r.photo : null,
    complainant: { name: r.name || null, mobile: r.phone },
    callbackUrl: base + '/api/govt/webhook',
    createdAt: new Date(r.created).toISOString()
  };
}

// How we read the ticket number out of their response.
function extractTicket(j) {
  return j && (j.ticketId || j.ticket_id || j.grievanceId || j.complaintId || j.id) || null;
}

async function forward(r) {
  const c = cfg();
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), 10000);
  try {
    const res = await fetch(c.url, {
      method: 'POST',
      signal: ctl.signal,
      headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + c.key, 'X-Api-Key': c.key },
      body: JSON.stringify(buildPayload(r, c.base))
    });
    const j = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error('Government platform answered HTTP ' + res.status);
    const ticket = extractTicket(j);
    if (!ticket) throw new Error('No ticket number in government response');
    return { ticket: String(ticket), live: c.live };
  } finally {
    clearTimeout(timer);
  }
}

// Turn whatever wording the government uses into our 3 statuses.
function normalizeStatus(s) {
  s = String(s || '').toLowerCase();
  if (/(resolv|clos|complet|solv|done|fixed|disposed)/.test(s)) return 'S';
  if (/(progress|assign|process|forward|work|inspect|started|ongoing)/.test(s)) return 'P';
  if (/(regist|receiv|open|new|pending|submitted)/.test(s)) return 'R';
  return null;
}

module.exports = { DEPARTMENTS, CATEGORIES, forward, normalizeStatus, cfg };
